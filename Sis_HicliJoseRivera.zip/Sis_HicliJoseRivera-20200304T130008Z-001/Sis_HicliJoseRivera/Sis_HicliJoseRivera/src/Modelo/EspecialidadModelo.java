package Modelo;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class EspecialidadModelo {

    private IntegerProperty IDESP;
    private StringProperty DESESP;
    private StringProperty ESRESP;

    public EspecialidadModelo(Integer IDESP, String DESESP, String ESRESP) {
        this.IDESP = new SimpleIntegerProperty(IDESP);
        this.DESESP = new SimpleStringProperty(DESESP);
        this.ESRESP = new SimpleStringProperty(ESRESP);

    }

    public Integer getIDESP() {
        return IDESP.get();
    }

    public void setIDAUT(Integer IDESP) {
        this.IDESP = new SimpleIntegerProperty(IDESP);
    }

    public String getDESESP() {
        return DESESP.get();
    }

    public void setDESESP(String DESESP) {
        this.DESESP = new SimpleStringProperty(DESESP);
    }

    public String getESRESP() {
        return ESRESP.get();
    }

    public void setESRESP(String ESRESP) {
        this.ESRESP = new SimpleStringProperty(ESRESP);
    }

    public IntegerProperty IDESPProperty() {
        return IDESP;
    }

    public StringProperty DESESPProperty() {
        return DESESP;
    }

    public StringProperty ESRESPProperty() {
        return ESRESP;
    }

}
