
package Modelo;

import java.sql.Date;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class HistoriaClinicaModelo {
    private IntegerProperty CODHISCLI;
     private StringProperty PESHISCLI;
     private StringProperty ALTHISCLI;
     private IntegerProperty IDPAC;
     private IntegerProperty IDTRA;
     private Date FECHISCLI;
     
        public HistoriaClinicaModelo(Integer CODHISCLI ,String PESHISCLI ,String ALTHISCLI, Integer IDPAC, Integer IDTRA ,Date FECHISCLI){
         this.CODHISCLI=new SimpleIntegerProperty(CODHISCLI);
         this.PESHISCLI=new SimpleStringProperty(PESHISCLI);
         this.ALTHISCLI=new SimpleStringProperty(ALTHISCLI);
         this.IDPAC=new SimpleIntegerProperty(IDPAC);
         this.IDTRA=new SimpleIntegerProperty(IDTRA);
          this.FECHISCLI=FECHISCLI;
         
      
        
     }
               public Integer getCODHISCLI(){
         return CODHISCLI.get();
     }
     
     public void setCODHISCLI(Integer CODHISCLI){
         this.CODHISCLI = new SimpleIntegerProperty(CODHISCLI);
     }
      public String getPESHISCLI(){
         return PESHISCLI.get();
     }
      public void setPESHISCLI(String PESHISCLI){
         this.PESHISCLI = new SimpleStringProperty(PESHISCLI);
     }
         public String getALTHISCLI(){
         return ALTHISCLI.get();
     }
      public void setALTHISCLI(String ALTHISCLI){
         this.ALTHISCLI = new SimpleStringProperty(ALTHISCLI);
     }
         public Integer getIDPAC(){
         return IDPAC.get();
     }
     
     public void setIDPAC(Integer IDPAC){
         this.IDPAC = new SimpleIntegerProperty(IDPAC);
     }
     public Integer getIDTRA(){
         return IDTRA.get();
     }
     
     public void setIDTRA(Integer IDTRA){
         this.IDTRA = new SimpleIntegerProperty(IDTRA);
     }   
        public Date getFECHISCLI(){
         return FECHISCLI;
     }
      public void setFECHISCLI(Date FECHISCLI){
         this.FECHISCLI = FECHISCLI;
     }
      
      
      
      
}


