
package Modelo;

import java.sql.Date;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class TrabajadorModelo {
       private IntegerProperty IDTRA;
    private PersonaModelo IDPER;
    private EspecialidadModelo IDESP;
    private EstablecimientoModelo IDEST;
    private StringProperty CARTRA;
    private Date FECREGTRA;
    private StringProperty EMAILTRA;
     private UsuarioModelo IDUSE;
       private StringProperty ESTTRA;

    public TrabajadorModelo(Integer IDTRA, PersonaModelo IDPER,EspecialidadModelo IDESP, EstablecimientoModelo IDEST,
            String CARTRA, Date FECREGTRA, String EMAILTRA, UsuarioModelo IDUSE, String ESTTRA) {
        this.IDTRA = new SimpleIntegerProperty(IDTRA);
        this.IDPER = IDPER;
         this.IDESP = IDESP;
        this.IDEST = IDEST;
        this.CARTRA = new SimpleStringProperty(CARTRA);
        this.FECREGTRA = FECREGTRA;
        this.EMAILTRA = new SimpleStringProperty(EMAILTRA);
         this.IDUSE = IDUSE;
         this.ESTTRA = new SimpleStringProperty(ESTTRA);

    }

     public Integer getIDTRA() {
        return IDTRA.get();
    }

    public void setIDTRA(Integer IDTRA) {
        this.IDTRA = new SimpleIntegerProperty(IDTRA);
    }

    public PersonaModelo getIDPER() {
        return IDPER;
    }

    public void setIDPER(PersonaModelo IDPER) {
        this.IDPER = IDPER;
    }
     public EspecialidadModelo getIDESP() {
        return IDESP;
    }

    public void setIDESP(EspecialidadModelo IDESP) {
        this.IDESP = IDESP;
    }
    
    public EstablecimientoModelo getIDEST(){
        return IDEST;
    }

    
    public void setIDEST(EstablecimientoModelo IDEST) {
        this.IDEST = IDEST;
    }


    public String getCARTRA() {
        return CARTRA.get();
    }

    public void setCARTRA(String CARTRA) {
        this.CARTRA = new SimpleStringProperty(CARTRA);
    }

    public Date getFECREGTRA() {
        return FECREGTRA;
    }

    public void setFECREGTRA(Date FECREGTRA) {
        this.FECREGTRA = FECREGTRA;
    }

    public String getEMAILTRA() {
        return EMAILTRA.get();
    }

    public void setEMAILTRA(String EMAILTRA) {
        this.EMAILTRA = new SimpleStringProperty(EMAILTRA);
    }
     public Integer getIDUSE() {
        return IDUSE.get();
    }

    public void setIDUSE(Integer IDUSE) {
        this.IDUSE = new SimpleIntegerProperty(IDUSE);
    }

    public String getESTTRA() {
        return ESTTRA.get();
    }

    public void setESTTRA(String ESTTRA) {
        this.ESTTRA = new SimpleStringProperty(ESTTRA);
    }
    
    
    
    
}
