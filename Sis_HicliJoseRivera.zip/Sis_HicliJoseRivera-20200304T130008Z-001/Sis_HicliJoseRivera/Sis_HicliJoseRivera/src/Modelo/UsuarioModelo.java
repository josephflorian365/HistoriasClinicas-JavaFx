
package Modelo;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class UsuarioModelo {
      private IntegerProperty IDUSE;
    private StringProperty NAMESU;
    private StringProperty PASUSE;
    private StringProperty TIPUSE;
    private StringProperty ESTUSE;
    
    
   public UsuarioModelo(Integer IDUSE,  String NAMESU, String PASUSE, String TIPUSE, String ESTUSE) {
        this.IDUSE = new SimpleIntegerProperty(IDUSE);
        this.NAMESU = new SimpleStringProperty(NAMESU);
        this.PASUSE = new SimpleStringProperty(PASUSE);
        this.TIPUSE = new SimpleStringProperty(TIPUSE);
        this.ESTUSE = new SimpleStringProperty(ESTUSE);

    }
     public Integer getIDUSE() {
        return IDUSE.get();
    }

    public void setIDUSE(Integer IDUSE) {
        this.IDUSE = new SimpleIntegerProperty(IDUSE);
    }

    public String getNAMESU() {
        return NAMESU.get();
    }

    public void setNAMESU(String NAMESU) {
        this.NAMESU = new SimpleStringProperty(NAMESU);
    }
    public String getPASUSE() {
        return PASUSE.get();
    }

    public void setPASUSE(String PASUSE) {
        this.PASUSE = new SimpleStringProperty(PASUSE);
    }
    public String getDIREST() {
        return TIPUSE.get();
    }

    public void setTIPUSE(String TIPUSE) {
        this.TIPUSE = new SimpleStringProperty(TIPUSE);
    }
    public String getESTUSE() {
        return ESTUSE.get();
    }

    public void setESTUSE(String ESTUSE) {
        this.ESTUSE = new SimpleStringProperty(ESTUSE);
    }
    
    
    
    
    
    
}
