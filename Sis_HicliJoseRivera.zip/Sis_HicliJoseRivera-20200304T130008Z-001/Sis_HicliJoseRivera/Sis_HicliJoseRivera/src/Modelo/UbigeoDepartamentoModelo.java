/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author PC09
 */
public class UbigeoDepartamentoModelo {
    private IntegerProperty IDDEP;
    private StringProperty UBIDEP;
    
    public UbigeoDepartamentoModelo(Integer IDDEP, String UBIDEP){
        this.IDDEP = new SimpleIntegerProperty(IDDEP);
        this.UBIDEP = new SimpleStringProperty(UBIDEP);
    }
    
    public Integer getIDDEP(){
        return IDDEP.get();
    }
    public void setIDDEP(Integer IDDEP){
        this.IDDEP = new SimpleIntegerProperty(IDDEP);
    }
    public String getUBIDEP(){
        return UBIDEP.get();
    }
    public void setUBIDEP(String UBIDEP){
    this.UBIDEP = new SimpleStringProperty(UBIDEP);
    }
    public IntegerProperty IDDEProperty(){
        return IDDEP;
    }
    public StringProperty UBIDEProperty(){
        return UBIDEP;
    }
}
