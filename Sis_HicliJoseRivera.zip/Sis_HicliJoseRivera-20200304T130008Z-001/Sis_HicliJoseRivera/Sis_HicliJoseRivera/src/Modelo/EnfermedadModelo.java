
package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Observable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;


public class EnfermedadModelo {
      private IntegerProperty CODENF;
     private StringProperty DESCENF;
     
     public EnfermedadModelo(Integer CODENF ,String DESCENF ){
         this.CODENF =new SimpleIntegerProperty(CODENF);
         this.DESCENF =new SimpleStringProperty(DESCENF);
}
    public Integer getCODENF(){
         return CODENF.get();
     }
     public void setCODENF(Integer CODENF){
         this. CODENF= new SimpleIntegerProperty(CODENF);
     }
    
     public String getDESCENF(){
         return DESCENF.get();
     }
     public void setDESCENF(Integer DESCENF){
         this. CODENF= new SimpleIntegerProperty(DESCENF);
     }
     
     public IntegerProperty CODENFProperty(){
         return CODENF;
     }
     public StringProperty DESCENFProperty(){
         return DESCENF;
     }
     
     public static void llenarInformacion(Connection connection, ObservableList<EnfermedadModelo>lista){
         try{
             Statement statement  = connection.createStatement();
             ResultSet resultado = statement.executeQuery("SELECT * FROM ENFERMEDAD");
             while(resultado.next()){
                 lista.add(
                         new EnfermedadModelo(resultado.getInt("CODENF"), resultado.getString("DESCENF"))
                 );
             }
         } catch (SQLException e) {
              e.printStackTrace();
          }
     }
     @Override
     public String toString(){
         return DESCENF.get();
     }
     
}