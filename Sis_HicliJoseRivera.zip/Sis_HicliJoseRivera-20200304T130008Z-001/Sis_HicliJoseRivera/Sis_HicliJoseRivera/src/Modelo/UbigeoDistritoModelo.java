/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author Js
 */
public class UbigeoDistritoModelo {
    private IntegerProperty IDDIS;
    private StringProperty UBIDIS;
    private UbigeoProvinciaModelo IDPRO;
    
    public UbigeoDistritoModelo(Integer IDDIS, String UBIDIS, UbigeoProvinciaModelo IDPRO){
        this.IDDIS = new SimpleIntegerProperty(IDDIS);
        this.UBIDIS = new SimpleStringProperty(UBIDIS);
        this.IDPRO= IDPRO;
    }
    
    public Integer getIDDIS(){
        return IDDIS.get();
    }
    public void setIDDIS(Integer IDDIS){
        this.IDDIS = new SimpleIntegerProperty(IDDIS);
    }
    public String getUBIDIS(){
        return UBIDIS.get();
    }
    public void setUBIDIS(String UBIDIS){
        this.UBIDIS = new SimpleStringProperty(UBIDIS);
    }
    public UbigeoProvinciaModelo getIDPRO(){
        return IDPRO;
    }
    public void setIDPRO(UbigeoProvinciaModelo IDPRO){
        this.IDPRO = IDPRO;
    }
    public IntegerProperty IDDISProperty(){
        return IDDIS;
    }
    public StringProperty UBIDISProperty(){
        return UBIDIS;
    }
}
