/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author Js
 */
public class UbigeoProvinciaModelo {

    private IntegerProperty IDPRO;
    private StringProperty UBIPRO;
    private UbigeoDepartamentoModelo IDDEP;

    public UbigeoProvinciaModelo(Integer IDPRO, String UBIPRO, UbigeoDepartamentoModelo IDDEP) {

        this.IDPRO = new SimpleIntegerProperty(IDPRO);
        this.UBIPRO = new SimpleStringProperty(UBIPRO);
        this.IDDEP = IDDEP;

    }
    
    public Integer getIDPRO(){
        return IDPRO.get();
    }
    public void setIDPRO(Integer IDPRO){
        this.IDPRO = new SimpleIntegerProperty();
    }
    public String getUBIPRO(){
        return UBIPRO.get();
    }
    public void setUBIPRO(String UBIPRO){
        this.UBIPRO = new SimpleStringProperty(UBIPRO);
    }
    public UbigeoDepartamentoModelo getIDDEP(){
        return IDDEP;
    }
    public void setIDDEP(UbigeoDepartamentoModelo IDDEP){
        this.IDDEP = IDDEP;
    }
    public IntegerProperty IDPRO(){
        return IDPRO;
    }
    public StringProperty UBIPRO(){
        return UBIPRO;
    }
    
   
}
