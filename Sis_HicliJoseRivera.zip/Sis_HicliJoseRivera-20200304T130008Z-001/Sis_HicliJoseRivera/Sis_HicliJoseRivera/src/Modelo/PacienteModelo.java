
package Modelo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Observable;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;


public class PacienteModelo {
     private IntegerProperty IDPAC;
     private PersonaModelo IDPER;
     private StringProperty ESTCIVPAC;
     private Date FECREGPAC;
     private StringProperty ESTPAC;
     
     public PacienteModelo(Integer IDPAC ,PersonaModelo IDPER ,String ESTCIVPAC, Date FECREGPAC, String ESTPAC ){
         this.IDPAC=new SimpleIntegerProperty(IDPAC);
         this.IDPER=IDPER;
         this.ESTCIVPAC=new SimpleStringProperty(ESTCIVPAC);
         this.FECREGPAC= FECREGPAC;
         this.ESTPAC=new SimpleStringProperty(ESTPAC);
       
         
        
     }

      public Integer getIDPAC(){
         return IDPAC.get();
     }
     
     public void setIDPAC(Integer IDPAC){
         this.IDPAC = new SimpleIntegerProperty(IDPAC);
     }
      public PersonaModelo getIDPER(){
         return IDPER;
     }
     
     public void setIDPER(PersonaModelo IDDIS){
         this.IDPER = IDPER;
     }
     public String getESTCIVPAC(){
         return ESTCIVPAC.get();
     }
     
     public void setESTCIVPAC(String ESTCIVPAC){
         this.ESTCIVPAC = new SimpleStringProperty(ESTCIVPAC);
     }
     public Date getFECREGPAC(){
         return FECREGPAC;
     }
     
     public void setFECREGPAC(Date FECREGPAC){
         this.FECREGPAC = FECREGPAC;
     }
     public String getESTPAC(){
         return ESTPAC.get();
     }
     
     public void setESTPAC(String ESTPAC){
         this.ESTPAC = new SimpleStringProperty(ESTPAC);
     }
     
     public IntegerProperty IDPACProperty(){
         return IDPAC;
     }
     public StringProperty ESTCIVPACProperty(){
         return ESTCIVPAC;
     }
     public StringProperty ESTPACProperty(){
         return ESTPAC;
     }
     
     public static void llenarINFORMACION(Connection connection, ObservableList<PacienteModelo>lista){
         try{
             Statement statement = connection.createStatement();
             ResultSet resultado = statement.executeQuery("SELECT * FROM PACIENTE");
             while(resultado.next()){
                 lista.add{
                 new PacienteModelo(Integer.SIZE, IDPER, ESTCIVPAC, FECREGPAC, ESTPAC)
             }
             }
         }
     }
     
     
     
     
     
}

