package Modelo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Observable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;

public class PersonaModelo {

    private IntegerProperty IDPER;
    private UbigeoDistritoModelo IDDIS;
    private StringProperty NOMPER;
    private StringProperty APEPER;
    private StringProperty CELPER;
    private StringProperty DNIPER;
    private StringProperty DIRPER;
    private Date FECNACPER;
    private StringProperty SEXPER;
    private StringProperty TPPER;
    private StringProperty ESTPER;

    public PersonaModelo(Integer IDPER, UbigeoDistritoModelo IDDIS,
             String NOMPER, String APEPER, String CELPER, String DNIPER,String DIRPER, Date FECNACPER, String SEXPER, String TPPER, String ESTPER) {
        this.IDPER = new SimpleIntegerProperty(IDPER);
        this.IDDIS = IDDIS;
        this.NOMPER = new SimpleStringProperty(NOMPER);
        this.APEPER = new SimpleStringProperty(APEPER);
        this.CELPER = new SimpleStringProperty(CELPER);
        this.DNIPER = new SimpleStringProperty(DNIPER);
        this.DIRPER = new SimpleStringProperty(DIRPER);
        this.FECNACPER = FECNACPER;
        this.SEXPER = new SimpleStringProperty(SEXPER);
        this.TPPER = new SimpleStringProperty(TPPER);
        this.ESTPER = new SimpleStringProperty(ESTPER);

    }
    
    public Integer getIDPER() {
        return IDPER.get();
    }

    public void setIDPER(Integer IDPER) {
        this.IDPER = new SimpleIntegerProperty(IDPER);
    }

    public UbigeoDistritoModelo getIDDIS() {
        return IDDIS;
    }

    public void setIDDIS(UbigeoDistritoModelo IDDIS) {
        this.IDDIS = IDDIS;
    }

    public String getNOMPERv() {
        return NOMPER.get();
    }

    public void setNOMPER(String NOMPER) {
        this.NOMPER = new SimpleStringProperty(NOMPER);
    }

    public String getAPEPER() {
        return APEPER.get();
    }

    public void setAPEPER(String APEPER) {
        this.APEPER = new SimpleStringProperty(APEPER);
    }

    public String getCELPER() {
        return CELPER.get();
    }

    public void setCELPER(String CELPER) {
        this.CELPER = new SimpleStringProperty(CELPER);
    }
     public String getDNIPER() {
        return DNIPER.get();
    }

    public void setDNIPER(String DNIPER) {
        this.DNIPER = new SimpleStringProperty(DNIPER);
    }
    
    public String getDIRPER(){
        return DIRPER.get();
    }
    
    public void setDIRPER(String DIRPER){
        this.DIRPER = new SimpleStringProperty(DIRPER);
    }
    
     public Date getFECNACPER() {
        return FECNACPER;
    }

    public void setFECNACPER(Date FECNACPER) {
        this.FECNACPER = FECNACPER;
    }
    
     public String getSEXPER() {
        return SEXPER.get();
    }

    public void setSEXPER(String SEXPER) {
        this.SEXPER = new SimpleStringProperty(SEXPER);
    }
       public String getTPPER() {
        return TPPER.get();
    }

    public void setTPPER(String TPPER) {
        this.TPPER = new SimpleStringProperty(TPPER);
    }
       public String getESTPER() {
        return ESTPER.get();
    }

    public void setESTPER(String ESTPER) {
        this.ESTPER = new SimpleStringProperty(ESTPER);
    }
    
    public IntegerProperty IDPERProperty(){
        return IDPER;
    }
    public StringProperty NOMPERProperty(){
        return NOMPER;
    }
    public StringProperty APEPERProperty(){
        return APEPER;
    }
    public StringProperty CELPERProperty(){
        return CELPER;
    }
    
    public StringProperty DNIPERProperty(){
        return DNIPER;
    }
    public StringProperty DIRPERProperty(){
        return DIRPER;
    }
    public StringProperty SEXPERProperty(){
        return SEXPER;
    }
    public StringProperty TPPERProperty(){
        return TPPER;
    }
    public StringProperty ESTPERProperty(){
        return ESTPER;
    }
            
    public static void llenarInformacion(Connection connection, ObservableList<PersonaModelo>lista){
        try{
            Statement statement = connection.createStatement();
            ResultSet resultado = statement.executeQuery("SELECT * FROM PACIENTE");
            while(resultado.next())
                lista.add(
                new PersonaModelo(resultado.getInt("IDPAC"), 
                        new UbigeoDistritoModelo(resultado.getInt("IDDIS"), resultado.getString("UBIDIS"), 
                        new UbigeoProvinciaModelo(resultado.getInt("IDPRO"), resultado.getString("UBIPRO"), 
                        new UbigeoDepartamentoModelo(resultado.getInt("IDDEP"), resultado.getString("UBIDEP")))), resultado.getString("NOMPER"), resultado.getString("APEPER"), resultado.getString("CELPER"), resultado.getString("DNIPER"),resultado.getString("DIRPER"), resultado.getDate("FECNACPER"), resultado.getString("SEXPER"), resultado.getString("TIPPER"), resultado.getString("ESTPER"))
                );
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
        @Override
        public String toString(){
        return IDDIS.getUBIDIS() + " "+ NOMPER.get() +" "+ APEPER.get()+" "+CELPER.get()+" "+DNIPER.get()+" "+DIRPER.get()+" "+FECNACPER.toString()+" "+SEXPER.get()+" "+TPPER.get()+" "+ESTPER.get();
    }
        
    }
    
    

