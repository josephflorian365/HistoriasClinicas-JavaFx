package Modelo;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class EstablecimientoModelo {

    private IntegerProperty IDEST;
    private UbigeoDistritoModelo IDDIS;
    private StringProperty NOMEST;
    private StringProperty DIREST;
    private StringProperty TELEST;
    private StringProperty ESTEST;

    public EstablecimientoModelo(Integer IDEST, UbigeoDistritoModelo IDDIS, String NOMEST, String DIREST, String TELEST, String ESTEST) {
        this.IDEST = new SimpleIntegerProperty(IDEST);
        this.IDDIS = IDDIS;
        this.NOMEST = new SimpleStringProperty(NOMEST);
        this.DIREST = new SimpleStringProperty(DIREST);
        this.TELEST = new SimpleStringProperty(TELEST);
        this.ESTEST = new SimpleStringProperty(ESTEST);

    }

    public Integer getIDEST() {
        return IDEST.get();
    }

    public void setIDEST(Integer IDEST) {
        this.IDEST = new SimpleIntegerProperty(IDEST);
    }

    public UbigeoDistritoModelo getIDDIS() {
        return IDDIS;
    }

    public void setIDDIS(UbigeoDistritoModelo IDDIS) {
        this.IDDIS = IDDIS;
    }
    
    public String getNOMEST(){
        return NOMEST.get();
    }
    
    public void setNOMEST(String NOMEST){
        this.NOMEST = new SimpleStringProperty(NOMEST);
    }
    
    public String getDIREST() {
        return DIREST.get();
    }

    public void setDIREST(String DIREST) {
        this.DIREST = new SimpleStringProperty(DIREST);
    }

    public String getTELEST() {
        return TELEST.get();
    }

    public void setTELEST(String TELEST) {
        this.TELEST = new SimpleStringProperty(TELEST);
    }

    public String getESTEST() {
        return ESTEST.get();
    }

    public void setESTEST(String ESTEST) {
        this.ESTEST = new SimpleStringProperty(ESTEST);
    }
    
    public IntegerProperty IDESTProperty(){
        return IDEST;
    }
    public StringProperty NOMESTProperty(){
        return NOMEST;
    }
    public StringProperty DIRESTProperty(){
        return DIREST;
    }
    public StringProperty TELESTProperty(){
        return TELEST;
    }
    public StringProperty ESTESTProperty(){
        return ESTEST;
    }
}
