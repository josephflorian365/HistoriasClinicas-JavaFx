
package Modelo;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class PacienteAcompañanteModelo {
     private IntegerProperty CODPACACO;
     private IntegerProperty IDPAC;
     private IntegerProperty IDPER;
     private StringProperty TIPACO;
     private StringProperty FECPACACO;
     private StringProperty ESTPACACO;
     
     public PacienteAcompañanteModelo(Integer CODPACACO ,Integer IDPAC ,Integer IDPER,String TIPACO, String FECPACACO, String ESTPACACO ){
         this.CODPACACO=new SimpleIntegerProperty(CODPACACO);
         this.IDPAC=new SimpleIntegerProperty(IDPAC);
         this.IDPER=new SimpleIntegerProperty(IDPER);
         this.TIPACO=new SimpleStringProperty(TIPACO);
         this.FECPACACO=new SimpleStringProperty(FECPACACO);
         this.ESTPACACO=new SimpleStringProperty(ESTPACACO);
         
        
     }
     
     
      public Integer getCODPACACO(){
         return CODPACACO.get();
     }
     
     public void setCODPACACO(Integer CODPACACO){
         this.CODPACACO = new SimpleIntegerProperty(CODPACACO);
     }
     
     
      public Integer getIDPAC(){
         return IDPAC.get();
     }
     
     public void setIDPAC(Integer IDPAC){
         this.IDPAC = new SimpleIntegerProperty(IDPAC);
         }
     
      public Integer getIDEST(){
         return IDPER.get();
     }
     
     public void setIDPER(Integer IDPER){
         this.IDPER = new SimpleIntegerProperty(IDPER);
     }
     public String getTIPACO(){
         return TIPACO.get();
     }
     
     public void setTIPACO(String TIPACO){
         this.TIPACO = new SimpleStringProperty(TIPACO);
     }
     public String getDFECPACACO(){
         return FECPACACO.get();
     }
     
     public void setFECPACACO(String FECPACACO){
         this.FECPACACO = new SimpleStringProperty(FECPACACO);
     }
     public String getESTPACACO(){
         return ESTPACACO.get();
     }
     
     public void setESTPACACO(String ESTPACACO){
         this.ESTPACACO = new SimpleStringProperty(ESTPACACO);
     }
     
     
     
     
     
     
     
     
}
