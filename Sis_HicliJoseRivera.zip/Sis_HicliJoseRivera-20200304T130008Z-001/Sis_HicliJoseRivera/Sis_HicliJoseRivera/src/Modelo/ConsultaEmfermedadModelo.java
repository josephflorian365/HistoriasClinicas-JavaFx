package Modelo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Observable;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;


public class ConsultaEmfermedadModelo {
     private IntegerProperty IDCONENF;
     private Date FECCONENF;
     private HistoriaClinicaModelo CODHISCLI;
     private EnfermedadModelo CODENF;
    
     
      public ConsultaEmfermedadModelo(Integer IDCONENF ,Date FECCONENF,HistoriaClinicaModelo CODHISCLI, EnfermedadModelo CODENF ){
         this.IDCONENF =new SimpleIntegerProperty(IDCONENF);
         this.FECCONENF = FECCONENF;
          this.CODHISCLI = CODHISCLI;
           this.CODENF = CODENF;
      }
       public Integer getIDCONENF(){
         return IDCONENF.get();
     }
        public void setIDCONENF(Integer IDCONENF){
         this. IDCONENF= new SimpleIntegerProperty(IDCONENF);
     }
       public Date getFECCONENF(){
         return FECCONENF;
     }
        public void setFECCONENF(Date FECCONENF){
         this. FECCONENF= FECCONENF;
     }    
          public HistoriaClinicaModelo getCODHISCLI(){
         return CODHISCLI;
     }
        public void setCODHISCLI(HistoriaClinicaModelo CODHISCLI){
         this.CODHISCLI= CODHISCLI;
     }    
        
            public EnfermedadModelo getCODENF(){
         return CODENF;
     }
        public void setCODENF(EnfermedadModelo CODENF){
         this. CODENF= CODENF;
     }    
        
         public IntegerProperty IDCONENFProperty(){
         return IDCONENF;
     }

    
     public static void llenarInformacion(Connection connection, ObservableList<ConsultaEmfermedadModelo>lista){
         try{
             Statement statement = connection.createStatement();
             ResultSet resultado = statement.executeQuery("SELECT * FROM CONSULTA_ENFERMEDAD");
             while(resultado.next()){
                 lista.add(
                 new ConsultaEmfermedadModelo(resultado.getInt("IDCONENF"), resultado.getDate("FECCONENF"), resultado, CODENF)
                 )
             }
         }
         
     }
     
    
}